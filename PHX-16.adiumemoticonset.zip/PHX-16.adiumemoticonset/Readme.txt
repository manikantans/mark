
Do not extract this .zip! - Place the whole .zip in "Program Files\Spark\xtra\emoticons".

--------

License info:

-Emoji icons provided free by EmojiOne.

-All emoji images belong to EmojiOne Inc., and cannot be extracted for use in other projects.

-To gain access to these emoji images, go here: https://www.emojione.com/developers/download

--------

Packaged for Spark Messenger by tfphoenix